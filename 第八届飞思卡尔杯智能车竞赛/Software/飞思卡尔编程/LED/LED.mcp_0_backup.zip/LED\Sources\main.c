#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */

void PLL_init_48M(void)
{
//Fpllclk = 2 * Foscclk * (SYNR+1)/(REFDV+1)      2*16*3/2=48MHz
  CLKSEL=0X00;
  PLLCTL_PLLON=1;
  SYNR=0x00|0x02; //0X00|0X02
  REFDV=0x80|0x01; //0X00|0X01;
  _asm(nop);
  _asm(nop);
  while(CRGFLG_LOCK!=1);                  
  CLKSEL=0x80; 
}

void delay(unsigned int x) 
{
  unsigned int i,j;
  for(i=0;i<x;i++)
  {
    for(j=0;j<24000;j++);
  }
}

void main(void) 
{
  EnableInterrupts
  PLL_init_48M();
  /* put your own code here */
  DDRA=0xff;
  for(;;) 
  {
    _FEED_COP(); /* feeds the dog */
    PORTA=0x00;
    delay(1000);
    PORTA=0xff;
    delay(1000);    
  } /* loop forever */
  /* please make sure that you never leave main */
}
