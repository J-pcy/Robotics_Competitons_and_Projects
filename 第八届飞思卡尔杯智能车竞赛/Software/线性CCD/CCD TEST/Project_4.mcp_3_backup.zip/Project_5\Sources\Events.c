#include "includes.h"


/*
*********************************************************************************************************
* Description: Global variable
*********************************************************************************************************
*/
unsigned char TimerFlag20ms = 0;



/*
*********************************************************************************************************
* Description: PITCh0IntISR
* Note: 1ms at 40M
*********************************************************************************************************
*/
#pragma CODE_SEG __NEAR_SEG NON_BANKED

__interrupt void PITCh0IntISR(void) {

    static unsigned char TimerCnt20ms = 0;
    unsigned char integration_piont;

    PITTF_PTF0 = 1;

    TimerCnt20ms++;

    /* �����ع�ʱ�����20ms�����ڵ��ع�� */
    integration_piont = 20 - IntegrationTime;
    if(integration_piont >= 2) {      /* �ع��С��2(�ع�ʱ�����18ms)�򲻽������ع� */
        if(integration_piont == TimerCnt20ms)
        StartIntegration();           /* �ع⿪ʼ */
    }

     

    if(TimerCnt20ms >= 20)
     {
        TimerCnt20ms = 0;
        TimerFlag20ms = 1;
    }

}

#pragma CODE_SEG DEFAULT